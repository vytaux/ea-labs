package bank.integration.jms;

public interface JMSSender {

	public void sendJMSMessage (String text);

}
