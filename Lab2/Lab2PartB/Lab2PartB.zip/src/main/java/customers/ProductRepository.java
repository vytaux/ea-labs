package customers;

public interface ProductRepository {

	void save(Product product) ;
}
