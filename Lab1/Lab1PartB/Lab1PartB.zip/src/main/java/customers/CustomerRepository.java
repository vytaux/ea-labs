package customers;

import org.springframework.stereotype.Repository;

public interface CustomerRepository {

	void save(Customer customer) ;

}
