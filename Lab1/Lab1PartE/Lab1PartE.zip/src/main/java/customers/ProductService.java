package customers;

public interface ProductService {

	void addProduct(String name);
}
